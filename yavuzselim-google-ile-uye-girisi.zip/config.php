<?php 

@session_start();
@ob_start();

$db = new PDO("mysql:host=localhost;dbname=googlegiris;charset=utf8","googlegiris","Kdh?t089") or die("bağlanmadı");

?>
<?php 

define('CLIENT_ID','410101718610-1q5hqcvv3225ja27gl0op8l4anjv205n.apps.googleusercontent.com');
define('CLIENT_SECRET','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');
define('CLIENT_REDIRECT_URL','https://googlegiris.petlevet.com/google-redirect.php');


?>